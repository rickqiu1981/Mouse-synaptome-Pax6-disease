%synaptome model
clear
clf

%uncomment the alternative you want to use
genotype = 1; %WT
%genotype = 2; %HET

%uncomment the alternative you want to use
use_pattern=1; %theta burst
%use_pattern=2; %gamma
%use_pattern=3; %theta
%use_pattern=4; %high gamma pairs

%uncomment the alternative you want to use
%age=1;  %P1
%age=7;  %P7
%age=28; %P28
age=35; %P35
%age=56; %P56

%uncomment the alternative you want to use
%save_data_file=0; %do not save the data
save_data_file=1; %save the data as column data and text

%uncomment the alternative you want to use
%save_figure=0; %do not save the figure(s)
save_figure=1; %save the figure(s) as png and pdf

%nothing below needs to be changed, but welcome to experiment yourself

%%%load synapse data
gradientData = load ('gradientData.txt'); %gradient data for the synapses
xyCoord = load ('xyCoord.txt'); %x-y coordinates for the synapses

%%%initialize some parameters
v=[0.25  130    5.4   13    0.45  860]; %see Zhu et al., 2018 for furhter info on these values which were set using 10 epochs theta burst data to scale EPSP amplitudes and time constants
epspThresh=2.5;
plotthresh=15;
%totTime = 1450; %stimulate with only 8 spikes
totTime = 3850; %for 20 spike stimulation
t = linspace(0, totTime, totTime);
maxsumpeaks=0;
minsumpeaks=10000; %probably big enough

%%%set up stimulation pattern
%20 spikes
st10=[25  50   75  100  225  250  275  300  425  450  475  500  625  650  675  700  825  850  875  900]; %theta burst
st20=[25   50   75  100  125  150  175  200  225  250  275  300  325  350  375  400  425  450  475  500]; %gamma
st30=[25   225   425   625   825  1025  1225  1425  1625  1825  2025  2225  2425  2625  2825  3025  3225  3425  3625  3825]; %theta
st40=[25    38   338   351   651   664   964   977  1277  1290  1590  1603  1903  1916  2216  2229  2529  2542  2842  2855]; %high gamma pairs

switch use_pattern
case 1
pattmat=[st10]; %theta burst
case 2
pattmat=[st20]; %gamma
case 3
pattmat=[st30]; %theta
case 4
pattmat=[st40]; %high gamma pairs
end

%%% modify gradient data to account for age differences
switch genotype
case 1 %WT
switch age
case 1 %P1
redfac1=0.214168;
redfac2=0.138259;
redfac3=0;
redfac4=0;
ageId=1;
case 7 %P7
redfac1=0.538005;
redfac2=0.549797;
redfac3=0.00546339;
redfac4=0.0386053;
ageId=2;
case 28 %P28
redfac1=0.807788;
redfac2=0.808242;
redfac3=0.454412;
redfac4=0.468183;
ageId=3;
case 35 %P35
redfac1=0.506152;
redfac2=0.504303;
redfac3=0.556242;
redfac4=0.634378;
ageId=4;
case 56 %P56
redfac1=0.697197;
redfac2=0.786341;
redfac3=0.804886;
redfac4=0.755452;
ageId=5;
end
case 2 %HET
switch age
case 1 %P1
redfac1=0.166438;
redfac2=0.186428;
redfac3=0.186844;
redfac4=0.223129;
ageId=1;
case 7 %P7
redfac1=0.00531691;
redfac2=0.0194718;
redfac3=0.0481673;
redfac4=0.0795286;
ageId=2;
case 28 %P28
redfac1=1;
redfac2=1;
redfac3=0.744366;
redfac4=0.756243;
ageId=3;
case 35 %P35
redfac1=0;
redfac2=0;
redfac3=1;
redfac4=1;
ageId=4;
case 56 %P56
redfac1=0.884219;
redfac2=0.885438;
redfac3=0.676033;
redfac4=0.68032;
ageId=5;
end
end


minv=min(gradientData(:,1));
maxv=max(gradientData(:,1));
diffshift=(maxv-minv)*(1-1*redfac1);
gradientData(:,1)=((gradientData(:,1)-minv)*redfac1)+minv+diffshift;

minv=min(gradientData(:,2));
maxv=max(gradientData(:,2));
diffshift=(maxv-minv)*(1-1*redfac2);
gradientData(:,2)=((gradientData(:,2)-minv)*redfac2)+minv+diffshift;

minv=min(gradientData(:,3));
maxv=max(gradientData(:,3));
diffshift=(maxv-minv)*(1-1*redfac3);
gradientData(:,3)=((gradientData(:,3)-minv)*redfac3)+minv+diffshift;

minv=min(gradientData(:,4));
maxv=max(gradientData(:,4));
diffshift=(maxv-minv)*(1-1*redfac4);
gradientData(:,4)=((gradientData(:,4)-minv)*redfac4)+minv+diffshift;

counts = zeros(length(pattmat(:,1)), length(xyCoord));
%%% iterate over all inputs and over all synapses
for patt=1:length(pattmat(:,1))
spikeTimes=pattmat(patt,:);
for all=1:length(xyCoord(:,1))

%compute EPSP shape
%depression
Ad=v(1)*gradientData(all,1);
tauD=v(2)*gradientData(all,2);
tD = linspace(0, 5*tauD, 5*tauD+1);
depr = Ad * exp(-tD/tauD);

%fast facilitation
fSaturation = 3.3;
Af=v(3)*gradientData(all,3);
tauF=v(4)*gradientData(all,4);
tF = linspace(0, 5*tauF, 5*tauF+1);
fac = Af * exp(-tF/tauF);

%slow facilitation
Aff=v(5);
tauFF=v(6);
tFF = linspace(0, 5*tauFF, 5*tauFF+1);
sfac = Aff * exp(-tFF/tauFF);

%the basic EPSP waveform
Ae = 1;
tau1 = 3.0;
tau2 = 0.4;
tE = linspace(0, tau1*10, tau1*10+1);
psp = Ae * (exp(-tE/tau1) - exp(-tE/tau2)); %tau1>tau2

totEpsp = zeros(1, totTime);
totE = zeros(1, totTime);

%first spike, no fac or depr (as no preceeding spikes)
if spikeTimes(1) < totTime
preFill = zeros(1, spikeTimes(1));
if length(preFill)+length(psp) < totTime
postFill = zeros(1, totTime-length(preFill)-length(psp));
epspTrace = [preFill psp postFill];
else
epspTrace = [preFill psp(1:totTime-length(preFill))];
end %if 
end %if
totEpsp=totEpsp+epspTrace;
totE=totE+epspTrace;

%second to last spike
for j=2:length(spikeTimes);
totDepr = ones(1, totTime);
totFac = ones(1, totTime);
totsFac = ones(1, totTime);
for i=1:j-1;
if spikeTimes(i) < totTime
preFill = zeros(1, spikeTimes(i));

%depression time profile
if length(preFill)+length(depr) < totTime
postFillDepr = zeros(1, totTime-length(preFill)-length(depr));
depression = [preFill depr postFillDepr];
else
depression = [preFill depr(1:totTime-length(preFill))];
end %if 

%facilitation time profile
if length(preFill)+length(fac) < totTime
postFillFac = zeros(1, totTime-length(preFill)-length(fac));
facilitation = [preFill fac postFillFac];
else
facilitation = [preFill fac(1:totTime-length(preFill))];
end %if 

%slow facilitaiton time profile
if length(preFill)+length(sfac) < totTime
postFillsFac = zeros(1, totTime-length(preFill)-length(sfac));
sfacilitation = [preFill sfac postFillsFac];
else
sfacilitation = [preFill sfac(1:totTime-length(preFill))];
end %if 

end %if spikeTimes(i) < totTime
%for each synapse, all input-induced traces are summed (superimposed)
totDepr=totDepr-depression;
totFac=totFac+facilitation+sfacilitation;  %should we add sfacilitation here?
end %for i=1:j-1;
totDepr = max(totDepr,0.0);
totFac = min(totFac,fSaturation);

Ae = totDepr(spikeTimes(j))*totFac(spikeTimes(j));
psp = Ae * (exp(-tE/tau1) - exp(-tE/tau2)); %tau1>tau2
if spikeTimes(j) < totTime
preFill = zeros(1, spikeTimes(j));
if length(preFill)+length(psp) < totTime
postFill = zeros(1, totTime-length(preFill)-length(psp));
epspTrace = [preFill psp postFill];
else
epspTrace = [preFill psp(1:totTime-length(preFill))];
end %if 
end %if
totEpsp=totEpsp+epspTrace;
totE=totE+(epspTrace);
end %for j=2:length(spikeTimes);

%normalize to amplitude of first EPSP
indm=find (t>20 & t<30);
peakE1=max(totEpsp(indm));
totEpsp=totEpsp/peakE1;

%%%find and sum up peak amplitudes of the EPSPs
searchinterv=[];
for i=1:length(spikeTimes)
searchinterv=[searchinterv; spikeTimes(i)-5 spikeTimes(i)+10];
end

peakVek=[];
for i=1:length(spikeTimes)
peakVek=[peakVek; max(totEpsp(searchinterv(i,1):searchinterv(i,2)))];
end

sumpeaks=sum(peakVek);
if sumpeaks > maxsumpeaks
maxsumpeaks = sumpeaks;
end
if sumpeaks < minsumpeaks
minsumpeaks = sumpeaks;
end

%set color scale, all simulations use the same color scale
eps=0.0001; %min and max below are truncated values, eps for col to stay strictly in [0,1]
%run the script once for each case of age*pattern to find out the min and max, printing the minsumpeaks and maxsumpeaks below, use the smallest (largest) of all cases
minsumpeaksreg=8.1-eps;
maxsumpeaksreg=62.2+eps;
rangepeaks=maxsumpeaksreg-minsumpeaksreg;
counts(patt, all) = (sumpeaks-minsumpeaksreg)/rangepeaks;

end %for all %all spikes
end %for patt %all patterns

minsumpeaks %uncomment to print value, update minsumpeaksreg if necessary
maxsumpeaks %uncomment to print value, update maxsumpeaksreg if necessary

%define z values for saving data
zMat=[];
for i=1:11
zMat = [zMat counts(1,(i-1)*11+1:(i-1)*11+11)]; %for plot3, rows are y, cols are x 
end
if save_data_file
genotypestr={'WT' 'HET'};
patternstr={'tb' 'g' 't' 'hg'};
agestr={'P1' 'P7' 'P28' 'P35' 'P56'};
filename=strcat('2Ddata_Int_', genotypestr(genotype), '_', agestr(ageId), '_', patternstr(use_pattern), '.txt');
fid = fopen(filename{:},'wt');
fprintf(fid,'%g\n', zMat');
end

%define z values for plot
zMat=[];
for i=1:11
zMat = [zMat; counts(1,(i-1)*11+1:(i-1)*11+11)]; %for plot3, rows are y, cols are x 
end
figure(1)
imagesc(zMat);
colormap(fake_parula());
maxLim = 1.0;
minLim = 0.0;
hAx = gca;
hAx.CLim = [minLim maxLim];
if save_figure
genotypestr={'WT' 'HET'};
patternstr={'tb' 'g' 't' 'hg'};
agestr={'P1' 'P7' 'P28' 'P35' 'P56'};
filename=strcat('2Dplot_', genotypestr(genotype), '_', agestr(ageId), '_', patternstr(use_pattern));
print(char(filename), '-dpng')
print(char(filename), '-dpdf')
end
